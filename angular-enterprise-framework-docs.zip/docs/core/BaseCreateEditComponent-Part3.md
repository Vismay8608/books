# BaseCreateEditComponent

Part 3: Methods API, Required Methods, Optional Hooks, Fixed Methods, Helper Methods.