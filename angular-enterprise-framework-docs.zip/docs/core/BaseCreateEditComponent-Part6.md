# BaseCreateEditComponent

Part 6: Lifecycle & Sequence Diagrams.