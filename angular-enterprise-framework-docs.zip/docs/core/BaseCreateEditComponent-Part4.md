# BaseCreateEditComponent

Part 4: Client & Server Validation Framework.