# BaseCreateEditComponent

Part 7: Enterprise Examples (Developer Cookbook).