
const fs = require('fs');
const path = require('path');

const directory = 'd:\\inventorySuite';
const customCssLines = [
    '    <!-- Custom CSS -->\n',
    '    <link rel="stylesheet" href="css/custom-table.css">\n',
    '    <link rel="stylesheet" href="css/custom-chat.css">\n',
    '    <link rel="stylesheet" href="css/custom-notifications.css">\n'
];

fs.readdir(directory, (err, files) => {
    if (err) {
        console.error("Could not list the directory.", err);
        process.exit(1);
    }

    let count = 0;
    files.forEach(file => {
        if (file.endsWith('.html')) {
            const filePath = path.join(directory, file);
            fs.readFile(filePath, 'utf8', (err, data) => {
                if (err) {
                    console.error(err);
                    return;
                }

                // Check for existing links
                const hasCustomNotif = data.includes('href="css/custom-notifications.css"');

                if (hasCustomNotif) return;

                const lines = data.split('\n');
                const newLines = [];
                let foundStyle = false;

                for (let i = 0; i < lines.length; i++) {
                    const line = lines[i];

                    // Insert before style.css
                    if (line.includes('href="css/style.css"') && !foundStyle) {
                        foundStyle = true;
                        newLines.push('    <link rel="stylesheet" href="css/custom-notifications.css">');
                        newLines.push(line);
                    } else {
                        newLines.push(line);
                    }
                }

                if (foundStyle) {
                    fs.writeFile(filePath, newLines.join('\n'), 'utf8', (err) => {
                        if (err) console.error(err);
                        else {
                            console.log(`Updated ${file}`);
                        }
                    });
                    count++;
                }
            });
        }
    });
});
