document.addEventListener("DOMContentLoaded", function () {

    // Sidebar Toggle
    const sidebarToggle = document.getElementById("sidebarToggle");
    const sidebar = document.getElementById("sidebar");

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener("click", function () {
            sidebar.classList.toggle("show");
        });
    }

    // Close sidebar when clicking outside on mobile
    document.addEventListener("click", function (event) {
        const isClickInsideSidebar = sidebar.contains(event.target);
        const isClickInsideToggle = sidebarToggle.contains(event.target);

        if (window.innerWidth < 992 && !isClickInsideSidebar && !isClickInsideToggle && sidebar.classList.contains("show")) {
            sidebar.classList.remove("show");
        }
    });

    // Initialize Tooltips & Popovers
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Initialize Toastr options
    if (typeof toastr !== 'undefined') {
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "timeOut": "3000"
        };
    }

    // --- Charts Initialization (if on Dashboard) ---

    // Revenue Chart (Line)
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
                datasets: [{
                    label: 'Revenue',
                    data: [12000, 19000, 15000, 25000, 22000, 30000, 28000, 35000],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { borderDash: [2, 2] } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // Traffic Chart (Doughnut)
    const trafficCtx = document.getElementById('trafficChart');
    if (trafficCtx) {
        new Chart(trafficCtx, {
            type: 'doughnut',
            data: {
                labels: ['Direct', 'Social', 'Referral'],
                datasets: [{
                    data: [55, 30, 15],
                    backgroundColor: ['#2563eb', '#3b82f6', '#eff6ff'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }

    // -- new Chart.js Graphs --

    // Bar Chart
    const barCtx = document.getElementById('barChart');
    if (barCtx) {
        new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                datasets: [{
                    label: 'Sales',
                    data: [5000, 7500, 6000, 9000],
                    backgroundColor: '#2563eb',
                    borderRadius: 4
                }, {
                    label: 'Returns',
                    data: [500, 1000, 750, 1200],
                    backgroundColor: '#e2e8f0',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true, grid: { display: false } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // Radar Chart
    const radarCtx = document.getElementById('radarChart');
    if (radarCtx) {
        new Chart(radarCtx, {
            type: 'radar',
            data: {
                labels: ['Speed', 'Reliability', 'Comfort', 'Safety', 'Efficiency'],
                datasets: [{
                    label: 'Model X',
                    data: [80, 90, 70, 85, 95],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.2)'
                }, {
                    label: 'Model Y',
                    data: [60, 75, 80, 70, 85],
                    borderColor: '#94a3b8',
                    backgroundColor: 'rgba(148, 163, 184, 0.2)'
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // Polar Area Chart
    const polarCtx = document.getElementById('polarChart');
    if (polarCtx) {
        new Chart(polarCtx, {
            type: 'polarArea',
            data: {
                labels: ['Red', 'Green', 'Yellow', 'Grey', 'Blue'],
                datasets: [{
                    data: [11, 16, 7, 3, 14],
                    backgroundColor: ['#ef4444', '#10b981', '#f59e0b', '#64748b', '#2563eb']
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // --- D3.js Initialization ---

    // D3 Bar Chart
    if (document.getElementById('d3BarChart') && typeof d3 !== 'undefined') {
        const data = [30, 80, 45, 60, 20, 90, 50];
        const width = 200, height = 150, barPadding = 5;

        const svg = d3.select("#d3BarChart")
            .append("svg")
            .attr("width", width)
            .attr("height", height);

        svg.selectAll("rect")
            .data(data)
            .enter()
            .append("rect")
            .attr("x", (d, i) => i * (width / data.length))
            .attr("y", d => height - d)
            .attr("width", width / data.length - barPadding)
            .attr("height", d => d)
            .attr("fill", "#2563eb");
    }

    // D3 Donut Chart
    if (document.getElementById('d3DonutChart') && typeof d3 !== 'undefined') {
        const width = 200, height = 200, margin = 10;
        const radius = Math.min(width, height) / 2 - margin;

        const svg = d3.select("#d3DonutChart")
            .append("svg")
            .attr("width", width)
            .attr("height", height)
            .append("g")
            .attr("transform", `translate(${width / 2},${height / 2})`);

        const data = { a: 9, b: 20, c: 30, d: 8, e: 12 };
        const color = d3.scaleOrdinal().domain(["a", "b", "c", "d", "e"]).range(d3.schemeBlues[5]);

        const pie = d3.pie().value(d => d[1]);
        const data_ready = pie(Object.entries(data));

        const arc = d3.arc().innerRadius(50).outerRadius(radius);

        svg.selectAll('whatever')
            .data(data_ready)
            .join('path')
            .attr('d', arc)
            .attr('fill', d => color(d.data[0]))
            .attr("stroke", "white")
            .style("stroke-width", "2px")
            .style("opacity", 0.7);
    }


    // --- DataTables Initialization ---
    if ($.fn.DataTable) {
        $('#ordersTable').DataTable({
            responsive: true,
            pageLength: 5,
            lengthMenu: [[5, 10, 25, -1], [5, 10, 25, "All"]],
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search orders..."
            }
        });
    }

});
