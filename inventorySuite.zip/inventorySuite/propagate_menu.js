
const fs = require('fs');
const path = require('path');

const SOURCE_FILE = 'd:\\inventorySuite\\security-sessions.html';
const TARGET_DIR = 'd:\\inventorySuite';

// Helper to read/write
function readFile(p) { return fs.readFileSync(p, 'utf8'); }
function writeFile(p, c) { fs.writeFileSync(p, c, 'utf8'); }

// Regex
const asideRegex = /(<aside id="sidebar" class="sidebar">[\s\S]*?<\/aside>)/;
const navRegex = /(<nav class="top-navbar">[\s\S]*?<\/nav>)/;

const parentMap = {
    'storeClientMenu': ['store-home.html', 'store-search-grid.html', 'store-cart.html', 'store-checkout.html', 'store-order-receipt.html', 'store-orders.html', 'store-product-details.html', 'store-wishlist.html'],
    'accountMenu': ['pages-account-overview.html', 'pages-account-user-profile.html', 'pages-account-company-profile.html', 'pages-account-settings.html', 'pages-account-settings-enterprise.html'],
    'securityMenu': ['security-overview.html', 'security-allowed-ips.html', 'security-privacy.html', 'security-device-management.html', 'security-backup-recovery.html', 'security-sessions.html', 'security-log.html']
};

try {
    const sourceContent = readFile(SOURCE_FILE);
    const asideMatch = sourceContent.match(asideRegex);
    const navMatch = sourceContent.match(navRegex);

    if (!asideMatch || !navMatch) {
        console.error("Could not find aside or nav in source.");
        process.exit(1);
    }

    let templateSidebar = asideMatch[1];
    const templateNavbar = navMatch[1];

    // Clean Sidebar
    // 1. Remove active
    templateSidebar = templateSidebar.replace(/class="sidebar-link active"/g, 'class="sidebar-link"');
    // 2. Remove show
    templateSidebar = templateSidebar.replace(/class="collapse sidebar-submenu show"/g, 'class="collapse sidebar-submenu"');
    // 3. Reset aria
    templateSidebar = templateSidebar.replace(/aria-expanded="true"/g, 'aria-expanded="false"');
    // 4. Reset collapsed (ensure it is present)
    templateSidebar = templateSidebar.replace(/class="sidebar-link has-arrow collapsed"/g, 'class="sidebar-link has-arrow"'); // normalize
    templateSidebar = templateSidebar.replace(/class="sidebar-link has-arrow"/g, 'class="sidebar-link has-arrow collapsed"'); // force all collapsed

    // Iterate
    const files = fs.readdirSync(TARGET_DIR);
    let count = 0;

    files.forEach(file => {
        if (!file.endsWith('.html')) return;
        const filePath = path.join(TARGET_DIR, file);
        let content = readFile(filePath);

        if (!content.includes('<aside id="sidebar"')) {
            console.log(`Skipped ${file} (no sidebar)`);
            return;
        }

        // Activate Link Logic
        let mySidebar = templateSidebar;

        // 1. Active Link
        // Simple string replace for the specific link
        // We look for 'href="filename" class="sidebar-link"'
        const linkPattern = `href="${file}" class="sidebar-link"`;
        const linkReplacement = `href="${file}" class="sidebar-link active"`;
        mySidebar = mySidebar.replace(linkPattern, linkReplacement);

        // 2. Expand Parent
        for (const [menuId, children] of Object.entries(parentMap)) {
            if (children.includes(file)) {
                // Expand UL
                const ulRegex = new RegExp(`class="collapse sidebar-submenu" id="${menuId}"`);
                mySidebar = mySidebar.replace(ulRegex, `class="collapse sidebar-submenu show" id="${menuId}"`);

                // Expand Toggle
                // Regex to find the anchor tag that TARGETS this menuId
                // The anchor usually looks like: <a class="sidebar-link has-arrow collapsed" ... href="#menuId" ...>
                // We want to remove 'collapsed' and set aria-expanded="true"

                // We'll search for the specific href="#menuId" and Capture the whole opening tag surrounding it to manipulate it.
                // Or easier: split by lines and find the line.

                const lines = mySidebar.split('\n');
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i].includes(`href="#${menuId}"`)) {
                        let line = lines[i];
                        line = line.replace('collapsed', ''); // remove collapsed class
                        line = line.replace('aria-expanded="false"', 'aria-expanded="true"');
                        lines[i] = line;
                        break; // found the toggle
                    }
                }
                mySidebar = lines.join('\n');
                break; // Found the parent, stop searching
            }
        }

        // Replace Sidebar Block
        content = content.replace(asideRegex, mySidebar);

        // Replace Navbar Block
        if (content.match(navRegex)) {
            content = content.replace(navRegex, templateNavbar);
        }

        writeFile(filePath, content);
        console.log(`Updated ${file}`);
        count++;
    });

    console.log(`Total files updated: ${count}`);

} catch (err) {
    console.error(err);
}
