
const fs = require('fs');
const path = require('path');

const directory = 'd:\\inventorySuite';
const customCssLines = [
    '    <!-- Custom CSS -->\n',
    '    <link rel="stylesheet" href="css/custom-table.css">\n',
    '    <link rel="stylesheet" href="css/custom-chat.css">\n'
];

let count = 0;

fs.readdir(directory, (err, files) => {
    if (err) {
        console.error("Could not list the directory.", err);
        process.exit(1);
    }

    files.forEach(file => {
        if (file.endsWith('.html')) {
            const filePath = path.join(directory, file);
            fs.readFile(filePath, 'utf8', (err, data) => {
                if (err) {
                    console.error(err);
                    return;
                }

                // Check for existing links
                const hasCustomTable = data.includes('href="css/custom-table.css"');
                const hasCustomChat = data.includes('href="css/custom-chat.css"');

                if (hasCustomTable && hasCustomChat) {
                    return;
                }

                const lines = data.split('\n');
                const newLines = [];
                let foundStyle = false;

                for (let i = 0; i < lines.length; i++) {
                    const line = lines[i];

                    if (line.includes('href="css/style.css"') && !foundStyle) {
                        foundStyle = true;
                        // Insert missing links before style.css
                        if (!hasCustomTable) {
                            newLines.push('    <link rel="stylesheet" href="css/custom-table.css">');
                        }
                        if (!hasCustomChat) {
                            newLines.push('    <link rel="stylesheet" href="css/custom-chat.css">');
                        }
                        newLines.push(line);
                    } else {
                        newLines.push(line);
                    }
                }

                if (foundStyle) {
                    fs.writeFile(filePath, newLines.join('\n'), 'utf8', (err) => {
                        if (err) console.error(err);
                        else {
                            console.log(`Updated ${file}`);
                        }
                    });
                    count++;
                } else {
                    console.log(`Skipped ${file} (no style.css link found)`);
                }
            });
        }
    });
});
