
import os
import re

# Source file with the "Golden" menu/navbar
SOURCE_FILE = r'd:\inventorySuite\security-sessions.html'
TARGET_DIR = r'd:\inventorySuite'

def get_file_content(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

def write_file_content(filepath, content):
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

def extract_section(content, start_marker, end_marker=None, tag_name=None):
    """
    Extracts a section. 
    If start_marker is a regex for a tag (e.g. <aside...), it tries to find the matching closing tag.
    This is a simple parser, assuming well-formed HTML.
    """
    # Simple regex extraction for now
    if tag_name == 'aside':
        pattern = re.compile(r'(<aside id="sidebar" class="sidebar">.*?</aside>)', re.DOTALL)
        match = pattern.search(content)
        return match.group(1) if match else None
    elif tag_name == 'nav':
        pattern = re.compile(r'(<nav class="top-navbar">.*?</nav>)', re.DOTALL)
        match = pattern.search(content)
        return match.group(1) if match else None
    return None

def clean_sidebar(sidebar_html):
    # 1. Remove 'active' class from links
    sidebar_html = re.sub(r'class="sidebar-link active"', 'class="sidebar-link"', sidebar_html)
    
    # 2. Remove 'show' from submenus
    sidebar_html = re.sub(r'class="collapse sidebar-submenu show"', 'class="collapse sidebar-submenu"', sidebar_html)
    
    # 3. Reset aria-expanded to false
    sidebar_html = re.sub(r'aria-expanded="true"', 'aria-expanded="false"', sidebar_html)
    
    # 4. Ensure all toggles are collapsed
    # First, remove 'collapsed' if it's there to avoid double adding
    sidebar_html = re.sub(r'class="sidebar-link has-arrow collapsed"', 'class="sidebar-link has-arrow"', sidebar_html)
    # Then add it back to all
    sidebar_html = re.sub(r'class="sidebar-link has-arrow"', 'class="sidebar-link has-arrow collapsed"', sidebar_html)
    
    return sidebar_html

def activate_sidebar_link(sidebar_html, filename):
    # 1. Activate the specific link
    # Pattern: href="filename"
    link_pattern = f'href="{filename}"'
    if link_pattern in sidebar_html:
        # Add active class
        # Look for the exact tag
        # We assume class="sidebar-link" is adjacent or nearby
        # Simple replacement: class="sidebar-link" -> class="sidebar-link active"
        # But only for this specific line.
        
        # Split by lines to process line by line (safer)
        lines = sidebar_html.split('\n')
        new_lines = []
        found_submenu_id = None
        
        for i, line in enumerate(lines):
            if link_pattern in line:
                line = line.replace('class="sidebar-link"', 'class="sidebar-link active"')
                # Check if this line is inside a submenu?
                # This simple line-by-line doesn't capture context easily.
                # However, we can look backwards to find the nearest parent <ul>
                # But HTML structure is nested.
                
                # Simpler approach: If we modify a line, we mark it.
            new_lines.append(line)
        
        sidebar_html = '\n'.join(new_lines)
        
        # 2. Handle Submenu expansion
        # We need to find which submenu contains the active link.
        # This requires more robust parsing or multipass regex.
        
        # Hacky reliable method:
        # Find the ID of the submenu containing the active link.
        # <ul class="collapse sidebar-submenu" id="ID"> ... <a href="filename" ...>
        
        # Regex to find id of parent UL
        # We search for the chunk: <ul ... id="GroupID"> ... href="filename"
        # This is hard because of nesting.
        
        # Specific known menus in this project:
        # #storeClientMenu -> store-home.html, etc.
        # #accountMenu -> pages-account-*.html
        # #securityMenu -> security-*.html
        
        parent_map = {
            'storeClientMenu': ['store-home.html', 'store-search-grid.html', 'store-cart.html', 'store-checkout.html', 'store-order-receipt.html', 'store-orders.html', 'store-product-details.html', 'store-wishlist.html'],
            'accountMenu': ['pages-account-overview.html', 'pages-account-user-profile.html', 'pages-account-company-profile.html', 'pages-account-settings.html', 'pages-account-settings-enterprise.html'],
            'securityMenu': ['security-overview.html', 'security-allowed-ips.html', 'security-privacy.html', 'security-device-management.html', 'security-backup-recovery.html', 'security-sessions.html', 'security-log.html']
        }
        
        for menu_id, files in parent_map.items():
            if filename in files:
                # Expand this menu
                # 1. Add 'show' to the UL
                sidebar_html = sidebar_html.replace(f'id="{menu_id}"', f'id="{menu_id}" class="collapse sidebar-submenu show"')
                # Remove duplicate class declaration if replace wasn't perfect (e.g. if it was class="collapse sidebar-submenu")
                sidebar_html = sidebar_html.replace(f'class="collapse sidebar-submenu" id="{menu_id}" class="collapse sidebar-submenu show"', f'class="collapse sidebar-submenu show" id="{menu_id}"')
                 # Replace the original cleanly
                sidebar_html = re.sub(f'class="collapse sidebar-submenu" id="{menu_id}"', f'class="collapse sidebar-submenu show" id="{menu_id}"', sidebar_html)

                # 2. Expand the toggle button
                # href="#menu_id"
                # remove 'collapsed'
                # set aria-expanded="true"
                toggle_pattern = re.compile(r'(<a class="sidebar-link has-arrow) collapsed(" data-bs-toggle="collapse" href="#' + menu_id + r'")')
                sidebar_html = toggle_pattern.sub(r'\1\2', sidebar_html) # remove collapsed
                
                toggle_attr_pattern = re.compile(r'(href="#' + menu_id + r'".*?aria-expanded=")false(")')
                sidebar_html = toggle_attr_pattern.sub(r'\1true\2', sidebar_html)
                
                break

    return sidebar_html


def main():
    # 1. Read Source
    source_content = get_file_content(SOURCE_FILE)
    
    # 2. Extract Components
    template_sidebar = extract_section(source_content, None, None, 'aside')
    template_navbar = extract_section(source_content, None, None, 'nav')
    
    if not template_sidebar or not template_navbar:
        print("Failed to extract sidebar or navbar from source.")
        return

    # 3. Clean Sidebar
    clean_base_sidebar = clean_sidebar(template_sidebar)

    # 4. Iterate files
    count = 0
    for filename in os.listdir(TARGET_DIR):
        if filename.endswith(".html"):
            filepath = os.path.join(TARGET_DIR, filename)
            content = get_file_content(filepath)
            
            # Check if file has a sidebar to begin with
            # (Avoid adding sidebar to pages that deliberately don't have one, like Auth pages maybe?)
            # But the user asked "display menu in all pages".
            # Usually Auth pages (pages-auth.html) have a different layout. 
            # If the file has <aside id="sidebar"...>, replace it.
            # If not, skip it.
            
            if '<aside id="sidebar"' in content:
                # 4a. Prepare Sidebar
                new_sidebar = activate_sidebar_link(clean_base_sidebar, filename)
                
                # Replace Sidebar
                content = re.sub(r'(<aside id="sidebar" class="sidebar">[\s\S]*?</aside>)', lambda m: new_sidebar, content)
                
                # 4b. Replace Navbar
                # Some pages might not have navbar?
                if '<nav class="top-navbar">' in content:
                     content = re.sub(r'(<nav class="top-navbar">[\s\S]*?</nav>)', lambda m: template_navbar, content)
                
                write_file_content(filepath, content)
                print(f"Updated {filename}")
                count += 1
            else:
                print(f"Skipped {filename} (no sidebar found)")

    print(f"Total files updated: {count}")

if __name__ == "__main__":
    main()
