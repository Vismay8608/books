
import os

directory = r'd:\inventorySuite'
custom_css_lines = [
    '    <!-- Custom CSS -->\n',
    '    <link rel="stylesheet" href="css/custom-table.css">\n',
    '    <link rel="stylesheet" href="css/custom-chat.css">\n'
]
style_css_link = '    <link rel="stylesheet" href="css/style.css">'

count = 0
for filename in os.listdir(directory):
    if filename.endswith(".html"):
        filepath = os.path.join(directory, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.readlines()
        
        # Check if custom css is already present
        has_custom_table = any('href="css/custom-table.css"' in line for line in content)
        has_custom_chat = any('href="css/custom-chat.css"' in line for line in content)
        
        if has_custom_table and has_custom_chat:
            continue
            
        new_content = []
        found_style = False
        
        for line in content:
            if 'href="css/style.css"' in line and not found_style:
                # Insert our links before style.css if they are missing
                if not has_custom_table:
                     new_content.append('    <link rel="stylesheet" href="css/custom-table.css">\n')
                if not has_custom_chat:
                     new_content.append('    <link rel="stylesheet" href="css/custom-chat.css">\n')
                
                # If the line had "<!-- Custom CSS -->" above it in the original file, we might end up with duplicate comments, 
                # but usually we just want to ensure the links are there.
                # simpler approach: Replace the style.css line with the block if we are strictly looking for that hook.
                
                found_style = True
                new_content.append(line)
            else:
                new_content.append(line)
        
        if found_style:
             with open(filepath, 'w', encoding='utf-8') as f:
                 f.writelines(new_content)
             count += 1
             print(f"Updated {filename}")
        else:
             print(f"Skipped {filename} (no style.css link found)")

print(f"Total updated files: {count}")
