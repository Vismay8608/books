import { Component, OnInit, HostListener } from '@angular/core';

interface State { id: number; name: string; }
interface City { id: number; name: string; stateId: number; }
interface Locality { id: number; name: string; cityId: number; }

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-location-selector',
  templateUrl: './location-selector.html',
  styleUrls: ['./location-selector.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class LocationSelector implements OnInit {

  // Fetch state list (to be replaced with AJAX call)
  async fetchStates(): Promise<State[]> {
    return this.states;
  }

  // Fetch city list for a state (to be replaced with AJAX call)
  async fetchCities(stateId: number): Promise<City[]> {
    return this.cities.filter(c => c.stateId === stateId);
  }

  // Fetch locality list for a city (to be replaced with AJAX call)
  async fetchLocalities(cityId: number): Promise<Locality[]> {
    return this.allLocalities.filter(l => l.cityId === cityId);
  }
  showLocalityDropdownHandler(event: Event) {
    event.stopPropagation();
    this.showStateDropdown = false;
    this.showCityDropdown = false;
    this.showLocalityDropdown = true;
  }
  resetAllLocalities() {
    this.localities = [];
    this.displayValue = `${this.stateName}, ${this.cityName}`;
    this.showStateDropdown = false;
    this.showCityDropdown = false;
    this.showLocalityDropdown = true;
  }
  onStateChipClick(event: Event) {
  event.stopPropagation();
  // Reset city and locality when clicking state chip
  this.cityId = null;
  this.cityName = '';
  this.localities = [];
  this.displayValue = this.stateName;
  this.showStateDropdown = true;
  this.showCityDropdown = false;
  this.showLocalityDropdown = false;
  }

  onCityChipClick(event: Event) {
  event.stopPropagation();
  // Reset only localities when clicking city chip
  this.localities = [];
  this.displayValue = `${this.stateName}, ${this.cityName}`;
  this.showStateDropdown = false;
  this.showCityDropdown = true;
  this.showLocalityDropdown = false;
  }

  onStateChipRemove(event: Event) {
    event.stopPropagation();
    this.stateId = null;
    this.stateName = '';
    this.cityId = null;
    this.cityName = '';
    this.localities = [];
    this.displayValue = '';
    this.showStateDropdown = true;
    this.showCityDropdown = false;
    this.showLocalityDropdown = false;
  }

  onCityChipRemove(event: Event) {
    event.stopPropagation();
    this.cityId = null;
    this.cityName = '';
    this.localities = [];
    this.displayValue = this.stateName;
    this.showStateDropdown = false;
    this.showCityDropdown = true;
    this.showLocalityDropdown = false;
  }
  onStateLinkClick(event: Event) {
    event.stopPropagation();
    this.showStateDropdown = true;
    this.showCityDropdown = false;
    this.showLocalityDropdown = false;
  }

  onCityLinkClick(event: Event) {
    event.stopPropagation();
    this.showStateDropdown = false;
    this.showCityDropdown = true;
    this.showLocalityDropdown = false;
    this.localities = [];
    this.updateDisplayValue();
  }
  private justSelected = false;

  displayValue = '';

  stateId: number | null = null;
  stateName = '';
  cityId: number | null = null;
  cityName = '';
  localities: Locality[] = [];

  showStateDropdown = false;
  showCityDropdown = false;
  showLocalityDropdown = false;

  stateSearchTerm = '';
  citySearchTerm = '';
  localitySearchTerm = '';

  states: State[] = [
    { id: 1, name: "Gujarat" },
    { id: 2, name: "Maharashtra" },
    { id: 3, name: "Karnataka" },
    { id: 4, name: "Tamil Nadu" },
    { id: 5, name: "Rajasthan" }
  ];

  cities: City[] = [
    { id: 1, name: "Ahmedabad", stateId: 1 },
    { id: 2, name: "Surat", stateId: 1 },
    { id: 3, name: "Mumbai", stateId: 2 },
    { id: 4, name: "Pune", stateId: 2 },
    { id: 5, name: "Bangalore", stateId: 3 },
    { id: 6, name: "Mysore", stateId: 3 }
  ];

  allLocalities: Locality[] = [
    { id: 1, name: "Satellite", cityId: 1 },
    { id: 2, name: "Vastrapur", cityId: 1 },
    { id: 8, name: "Navrangpura", cityId: 1 },
    { id: 9, name: "Paldi", cityId: 1 },
    { id: 10, name: "Maninagar", cityId: 1 },
    { id: 11, name: "Bopal", cityId: 1 },
    { id: 12, name: "Thaltej", cityId: 1 },
    { id: 13, name: "Gota", cityId: 1 },
    { id: 14, name: "Chandkheda", cityId: 1 },
    { id: 15, name: "Naranpura", cityId: 1 },
    { id: 16, name: "Sabarmati", cityId: 1 },
    { id: 17, name: "Memnagar", cityId: 1 },
    { id: 18, name: "Ambawadi", cityId: 1 },
    { id: 19, name: "Ellis Bridge", cityId: 1 },
    { id: 20, name: "Shahibaug", cityId: 1 },
    { id: 21, name: "Jodhpur", cityId: 1 },
    { id: 22, name: "Ranip", cityId: 1 },
    { id: 23, name: "Isanpur", cityId: 1 },
    { id: 24, name: "Gulbai Tekra", cityId: 1 },
    { id: 25, name: "Sola", cityId: 1 },
    { id: 3, name: "Adajan", cityId: 2 },
    { id: 4, name: "Vesu", cityId: 2 },
    { id: 5, name: "Andheri", cityId: 3 },
    { id: 6, name: "Bandra", cityId: 3 },
    { id: 7, name: "Powai", cityId: 3 }
  ];

  filteredStates: State[] = [];
  filteredCities: City[] = [];
  filteredLocalities: Locality[] = [];

  ngOnInit() {
    this.filteredStates = this.states;
  }

  onInputClick(event: Event) {
    event.stopPropagation();
    if (!this.stateId) {
      // No state selected, show state dropdown
      this.showStateDropdown = true;
      this.showCityDropdown = false;
      this.showLocalityDropdown = false;
    } else if (!this.cityId) {
      // State selected, but no city, show city dropdown
      this.showStateDropdown = false;
      this.showCityDropdown = true;
      this.showLocalityDropdown = false;
    } else {
      // Both selected, allow user to reset: show city dropdown and reset only localities
      this.showStateDropdown = false;
      this.showCityDropdown = true;
      this.showLocalityDropdown = false;
      this.localities = [];
      this.displayValue = `${this.stateName}, ${this.cityName}`;
    }
  }

  onStateSearch(event: any) {
    const term = event.target.value.toLowerCase();
    this.filteredStates = this.states.filter(s => s.name.toLowerCase().includes(term));
  }

  selectState(state: State) {
    this.justSelected = true;
    this.stateId = state.id;
    this.stateName = state.name;
    this.cityId = null;
    this.cityName = '';
    this.localities = [];
    this.displayValue = state.name;
    this.filteredCities = [];
    this.filteredLocalities = [];

    this.showStateDropdown = false;
    this.showCityDropdown = true;
    this.showLocalityDropdown = false;

    // Fetch cities for selected state
    this.fetchCities(state.id).then(cities => {
      this.filteredCities = cities;
    });
    this.citySearchTerm = '';
  }

  onCitySearch(event: any) {
    const term = event.target.value.toLowerCase();
    this.filteredCities = this.cities.filter(c =>
      c.stateId === this.stateId && c.name.toLowerCase().includes(term)
    );
  }

  selectCity(city: City) {
    this.justSelected = true;
    this.cityId = city.id;
    this.cityName = city.name;
    this.localities = [];
    this.displayValue = `${this.stateName}, ${city.name}`;

    this.showCityDropdown = false;
    this.showLocalityDropdown = true;

    // Fetch localities for selected city
    this.fetchLocalities(city.id).then(localities => {
      this.filteredLocalities = localities;
    });
    this.localitySearchTerm = '';
  }

  onLocalitySearch(event: any) {
    const term = event.target.value.toLowerCase();
    this.filteredLocalities = this.allLocalities.filter(l =>
      l.cityId === this.cityId && l.name.toLowerCase().includes(term)
    );
  }

  toggleLocality(locality: Locality) {
    const index = this.localities.findIndex(l => l.id === locality.id);
    if (index > -1) {
      this.localities.splice(index, 1);
      this.updateDisplayValue();
      // If all localities are removed, show city dropdown
      if (this.localities.length === 0) {
        this.showStateDropdown = false;
        this.showCityDropdown = true;
        this.showLocalityDropdown = false;
      }
    } else {
      this.localities.push(locality);
      this.updateDisplayValue();
    }
  }

  isLocalitySelected(locality: Locality) {
    return this.localities.some(l => l.id === locality.id);
  }

  updateDisplayValue() {
    if (this.localities.length > 0) {
      const first = this.localities[0].name;
      const more = this.localities.length - 1;
      if (more > 0) {
        this.displayValue = `${this.stateName}, ${this.cityName} - ${first} +${more} more`;
      } else {
        this.displayValue = `${this.stateName}, ${this.cityName} - ${first}`;
      }
    } else if (this.cityName) {
      this.displayValue = `${this.stateName}, ${this.cityName}`;
    } else {
      this.displayValue = this.stateName;
    }
  }


  @HostListener('document:click', ['$event'])
  clickOutside(event: Event) {
    if (this.justSelected) {
      this.justSelected = false;
      return;
    }
    this.showStateDropdown = false;
    this.showCityDropdown = false;
    this.showLocalityDropdown = false;
  }

  stopDropdownClick(event: Event) {
    event.stopPropagation();
  }

}
