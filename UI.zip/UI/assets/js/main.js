document.addEventListener('DOMContentLoaded', () => {
    // Sidebar Toggle
    const sidebar = document.querySelector('.ps-sidebar');
    const sidebarToggle = document.querySelector('.ps-sidebar-toggle');
    const overlay = document.querySelector('.ps-overlay');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            if (overlay) overlay.classList.toggle('active');
        });
    }

    if (overlay) {
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }

    // Dropdown Toggles
    const dropdownTriggers = document.querySelectorAll('[data-toggle="dropdown"]');

    dropdownTriggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            const target = document.querySelector(trigger.dataset.target);

            // Close all other dropdowns
            document.querySelectorAll('.ps-dropdown-menu').forEach(menu => {
                if (menu !== target) menu.classList.remove('show');
            });

            if (target) target.classList.toggle('show');
        });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
        document.querySelectorAll('.ps-dropdown-menu').forEach(menu => {
            menu.classList.remove('show');
        });
    });

    // Dark Mode Toggle (Optional implementation)
    const darkModeToggle = document.querySelector('#darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            // Save preference
            const isDark = document.body.classList.contains('dark-mode');
            localStorage.setItem('ps-theme', isDark ? 'dark' : 'light');
        });
    }

    // Load Theme Preference
    const savedTheme = localStorage.getItem('ps-theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
    }

    // Tabs Logic
    const tabs = document.querySelectorAll('[data-toggle="tab"]');
    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSelector = tab.dataset.target;
            const targetContent = document.querySelector(targetSelector);

            // Remove active class from siblings
            const parent = tab.closest('.ps-tabs-nav');
            if (parent) {
                parent.querySelectorAll('[data-toggle="tab"]').forEach(t => t.classList.remove('active'));
            }
            tab.classList.add('active');

            // Show content
            // Note: This is a simple implementation. For full tabs, you'd hide others.
            // Assuming simplified usage for now where we just toggle active state on nav.
        });
    });

    // =========================================
    // Carousel Logic
    // =========================================
    const carousels = document.querySelectorAll('.ps-carousel');

    carousels.forEach((carousel, index) => {
        const items = carousel.querySelectorAll('.ps-carousel-item');
        const indicators = carousel.querySelectorAll('.ps-carousel-indicators li');
        const prevBtn = carousel.querySelector('.ps-carousel-prev');
        const nextBtn = carousel.querySelector('.ps-carousel-next');

        let currentIndex = 0;
        let intervalId;
        const autoPlay = carousel.getAttribute('data-autoplay') === 'true';
        const delay = 5000; // 5 seconds

        const showSlide = (index) => {
            // Validate index
            if (index < 0) {
                currentIndex = items.length - 1;
            } else if (index >= items.length) {
                currentIndex = 0;
            } else {
                currentIndex = index;
            }

            // Update items
            items.forEach(item => item.classList.remove('active'));
            items[currentIndex].classList.add('active');

            // Update indicators
            if (indicators.length > 0) {
                indicators.forEach(ind => ind.classList.remove('active'));
                indicators[currentIndex].classList.add('active');
            }
        };

        const nextSlide = () => {
            showSlide(currentIndex + 1);
        };

        const prevSlide = () => {
            showSlide(currentIndex - 1);
        };

        // Event Listeners
        if (nextBtn) {
            nextBtn.addEventListener('click', (e) => {
                e.preventDefault();
                nextSlide();
                resetAutoplay();
            });
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', (e) => {
                e.preventDefault();
                prevSlide();
                resetAutoplay();
            });
        }

        if (indicators.length > 0) {
            indicators.forEach((ind, i) => {
                ind.addEventListener('click', () => {
                    showSlide(i);
                    resetAutoplay();
                });
            });
        }

        // Autoplay Logic
        const startAutoplay = () => {
            if (autoPlay) {
                intervalId = setInterval(nextSlide, delay);
            }
        };

        const stopAutoplay = () => {
            if (intervalId) {
                clearInterval(intervalId);
            }
        };

        const resetAutoplay = () => {
            stopAutoplay();
            startAutoplay();
        };

        // Init
        startAutoplay();

        // Pause on hover (optional)
        carousel.addEventListener('mouseenter', stopAutoplay);
        carousel.addEventListener('mouseleave', startAutoplay);
    });

    // Modals Logic
    const initModals = () => {
        const triggers = document.querySelectorAll('[data-toggle="modal"]');
        const modals = document.querySelectorAll('.ps-modal');

        triggers.forEach(trigger => {
            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = trigger.getAttribute('data-target');
                const modal = document.querySelector(targetId);
                if (modal) {
                    modal.classList.add('show');
                }
            });
        });

        // Close buttons (data-dismiss="modal")
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', () => {
                const modal = btn.closest('.ps-modal');
                if (modal) {
                    modal.classList.remove('show');
                }
            });
        });

        // Click outside to close
        modals.forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('show');
                }
            });
        });
    };
    initModals();

    // Collapse Logic (Sidebar Submenus)
    const collapseTriggers = document.querySelectorAll('[data-toggle="collapse"]');
    collapseTriggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = trigger.getAttribute('data-target');
            // If target is null (e.g. mobile toggle might use this, but we handle that separately), skip
            if (!targetId) return;

            const target = document.querySelector(targetId);
            if (target) {
                // Toggle display
                if (target.style.display === 'none' || !target.style.display) {
                    target.style.display = 'block';
                    trigger.classList.remove('collapsed');
                    trigger.setAttribute('aria-expanded', 'true');
                } else {
                    target.style.display = 'none';
                    trigger.classList.add('collapsed');
                    trigger.setAttribute('aria-expanded', 'false');
                }
            }
        });
    });

    // Alert Dismiss Logic
    const dismissButtons = document.querySelectorAll('[data-dismiss="alert"]');
    dismissButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const alert = btn.closest('.ps-alert');
            if (alert) {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.3s ease, margin 0.3s ease';
                setTimeout(() => {
                    alert.remove();
                }, 300);
            }
        });
    });
});
